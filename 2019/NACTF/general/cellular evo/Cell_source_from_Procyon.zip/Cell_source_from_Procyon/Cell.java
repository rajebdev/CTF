import java.awt.Color;

// 
// Decompiled by Procyon v0.5.36
// 

public class Cell
{
    public static void main(final String[] array) {
        final CellFrame cellFrame = new CellFrame();
        cellFrame.setBackground(Color.white);
        cellFrame.setVisible(true);
    }
}
